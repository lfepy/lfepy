# __init__.py in the main package
__version__ = '1.0.4'
__author__ = ["Dr. Prof. Khalid M. Hosny", "BSc. Mahmoud A. Mohamed", "Dr. Rania Salama", "Dr. Ahmed M. Elshewey"]
__license__ = 'MIT'

# Example of a package-wide configuration
DEBUG = False