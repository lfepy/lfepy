# __init__.py in the main package
__version__ = '1.0.9'
__author__ = ["Dr. Prof. Khalid M. Hosny", "BSc. Mahmoud A. Mohamed", "Dr. Essa E. Almazroei"]
__license__ = 'MIT'

# Example of a package-wide configuration
DEBUG = False